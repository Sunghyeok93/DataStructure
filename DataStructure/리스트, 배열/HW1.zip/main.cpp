#include <stdio.h>
#include "linkedlist.h"
#include <stdlib.h>
#include <Windows.h>
#include <string.h>

void print_pword(char(*p)[100], int);
void input(LinkedList *lp, char(*p)[100], int *word_cnt, int * try_cnt);
void sort_pword(char(*p)[100]);

int main(void)
{
	int try_cnt=1;
	int word_cnt = 5;
	char pword[6][100];
	
	FILE *fp;
	fp = fopen("C:\\data\\pointWord.txt", "rt");
	
	LinkedList list;
	create(&list);
	char start_w[100];
	strcpy(start_w, "pointer");
	start_word(&list, start_w);
	for (int i = 0; i < 5; i++)
	{
		fscanf(fp,"%s", pword[i]);
	}
	sort_pword(pword);

	while (word_cnt != 0)
	{
		print_pword(pword, word_cnt);
		display(&list, printword);
		input(&list,pword, &word_cnt, &try_cnt);
		fflush(stdin);
		printf("\n");
	}
	printf("**����Ʈ �ܾ ��� ������ϴ�. ������ �����մϴ�.");
}
void sort_pword(char(*p)[100])
{
	char tmp[100];
	for (int i = 0; i < 5; i++)
	{
		for (int j = i + 1; j < 5; j++)
		{
			if (strcmp(p[i], p[j]) > 0)
			{
				strcpy(tmp, p[i]);
				strcpy(p[i], p[j]);
				strcpy(p[j], tmp);
			}
		}
	}
}
void input(LinkedList *lp, char(*p)[100], int *word_cnt, int * try_cnt)
{
	char input_word[100];
	printf("�����ձ� �ܾ� �Է�(%dȸ��) : ",*try_cnt);
	scanf("%s", input_word, sizeof(input_word));
	fflush(stdin);
	int length = strlen(lp->tail->prev->word);
	for (int i = 0; i < *word_cnt; i++)
	{
		if ((lp->tail->prev->word)[length-1] == input_word[0] && strcmp(p[i], input_word) == 0)
		{
			appendFromTail(lp, input_word);

			for (int j = i; j < *word_cnt; j++)
			{
				strcpy(p[j],p[j+1]);
			}
			(*try_cnt)++;
			(*word_cnt)--;
			return;
		}
	}
	if ((lp->tail->prev->word)[length - 1] == input_word[0])
	{
		appendFromTail(lp, input_word);
		(*try_cnt)++;
		return;
	}
	
	for (int i = 0; i < *word_cnt; i++)
	{
		int len = strlen(p[i]);
		if (p[i][len-1] == input_word[0])
		{
			appendFromTail(lp, input_word);
			(*try_cnt)++;
			return;
		}
	}
	printf("�߸� �Է��ϼ̽��ϴ�.\n");
}
void print_pword(char(*p)[100], int word_cnt)
{
	printf("*����Ʈ �ܾ�      : ");
	for (int i = 0; i < word_cnt; i++)
	{
		printf("%s / ", p[i]);
	}
}