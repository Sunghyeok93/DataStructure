#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
#include "dataType.h"
#include <string.h>


void printPattern(DataType *p)
{
	printf("[ %s ] : %d ��\n", p->pattern, p->cnt);
}

int comparePatternPattern(DataType * p1, DataType * p2)
{
	if (strcmp(p1->pattern, p2->pattern) == 0)
	{
		return 1;
	}
	else if (strcmp(p1->pattern, p2->pattern) == 1)
	{
		return -1;
	}
	return -1;
}
int comparePatternNum(DataType *p1, DataType *p2)
{
	if (atoi(p1->pattern)<atoi(p2->pattern))
		return 1;
	else
		return -1;
}

int comparePatternCnt(DataType * p1, DataType * p2)
{
	if (p1->cnt == p2->cnt)	
	{
		return 1;
	}
	return -1;
}

