#include<stdio.h>
#include<stdlib.h>
#include"dataType.h"
#include<string.h>
#include"linkedlist.h"


int input_n(int *n);
void input_node(LinkedList *lp, char num[100], int *n);
void sort_node(LinkedList *lp);


int main(void)
{
	char num[3][100];
	FILE *fp;
	fp = fopen("C:\\data\\patternData.txt", "rt");
	for (int i = 0; i < 3; i++)
	{
		fscanf(fp, "%s",num[i]);
	}
	int n;
	input_n(&n);

	for (int i = 0; i < 3; i++)
	{
		LinkedList list;
		create(&list);
		printf("** ��Ʈ�� : [%s]�� �˻� ��� **", num[i]);
		input_node(&list, num[i], &n);
		sortList(&list,comparePatternNum);
		display(&list, printPattern);
		printf("\n");
		destroy(&list);
	}
}
void input_node(LinkedList *lp, char num[100], int *n)
{
	char tmp[8];
	int j = 0;
	Pattern tmpdata = { " " , 1 };
	Node *res;
	while (tmp[(*n) - 1] != NULL)
	{
		strncpy(tmp, &num[j], *n);
		for (int i = 0; i < 8; i++)
		{
			if (tmp[i] >= '0'&& tmp[i] <= '1')
			{
				;
			}
			else
			{
				tmp[i] = NULL;
			}
		}
		if (tmp[(*n) - 1] == NULL)
		{
			break;
		}

		//tmp[*n] = '\n';
		strcpy(tmpdata.pattern,tmp);

		//printf("%s\n", tmpdata.pattern);
		res = searchUnique(lp, &tmpdata, comparePatternPattern);
		if (res!=NULL)
		{
			(res->data.cnt)++;
		}
		else
		{
			appendFromHead(lp, &tmpdata);
		}

		/*res = searchUnique(lp, &temp, comparePersonName);
		if (res != NULL) printPerson(&res->data);
		else printf("�׷� ��� ����!\n");*/
		j++;
	}
}
void sort_node(LinkedList *lp)
{

}
int input_n(int *n)
{
	int num;
	while (1)
	{
		printf("* �˻��� ������ ���̸� �Է��Ͻÿ� : ");
		scanf("%d", &num);
		if (num >= 1 && num <= 7)
		{
			*n = num;
			return 1;
		}
		else
		{
			printf("�ٽ� �Է��ϼ���~\n");
		}
	}
}