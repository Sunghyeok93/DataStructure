
typedef int DataType;