#pragma once

typedef int DataType;

void printInt(DataType *p);
