#pragma once
typedef int DataType;

int compareInt(DataType *p1, DataType *p2);
void printInt(DataType *p);

